const express = require('express');
const { MongoClient } = require('mongodb');
const path = require('path');

const app = express();
const port = 3000;
const mongoUrl = 'mongodb://127.0.0.1:27017';
const dbName = 'hospital';
let db;

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(express.static(path.join(__dirname, 'public')));

MongoClient.connect(mongoUrl)
  .then(client => {
    db = client.db(dbName);
    console.log('✅ Connected to MongoDB');

    // Insert sample patients if collection is empty
    return db.collection('patients').countDocuments()
      .then(count => {
        if (count === 0) {
          return db.collection('patients').insertMany([
            { patientId: "P001", lname: "Park", fname: "Jihyo", age: 26 },
            { patientId: "P002", lname: "Min", fname: "Yoongi", age: 30 },
            { patientId: "P003", lname: "Im", fname: "Nayeon", age: 27 }
          ]);
        }
      });
  })
  .catch(err => console.error('❌ MongoDB connection error:', err));

app.get('/', async (req, res) => {
  const patients = await db.collection('patients').find().toArray();
  res.render('index', { patients });
});

app.listen(port, () => {
  console.log(`🚀 App running at http://localhost:${port}`);
});
