const express = require('express');
const path = require('path');
const app = express();
const port = 8080;

// Serve static files (like .html, .css, .js) from the 'public' directory
app.use(express.static(path.join(__dirname, 'public')));

// Redirect root (/) to home.html explicitly
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'home.html'));
});

// Optional: Add friendly routes for /book and /cart
app.get('/book', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'book.html'));
});

app.get('/cart', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'cart.html'));
});

app.listen(port, () => {
  console.log(`Server is running at http://localhost:${port}`);
});