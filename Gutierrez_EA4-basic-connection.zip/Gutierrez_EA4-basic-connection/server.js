const express = require('express');
const { MongoClient } = require('mongodb');
const path = require('path');

const app = express();
const port = 3000;
const url = 'mongodb://127.0.0.1:27017';
const dbName = 'ea4project';

app.use(express.static('public'));
app.use(express.json());

let db;

MongoClient.connect(url)
  .then(client => {
    db = client.db(dbName);
    console.log('✅ Connected to MongoDB');

    // Insert one document when the server starts
    return db.collection('sample').insertOne({ message: 'EA4 success' });
  })
  .then(() => console.log('📥 Sample data inserted'))
  .catch(err => console.error('❌ Error:', err));

app.get('/check', async (req, res) => {
  const result = await db.collection('sample').find().toArray();
  res.json(result);
});

app.listen(port, () => {
  console.log(`🚀 Server running at http://localhost:${port}`);
});
