use('exam')  


db.quiz1.insertMany([
  { studid: "2023001", lname: "Gutierrez", fname: "Princess", score: 95 },
  { studid: "2023002", lname: "Santos", fname: "Maria", score: 88 },
  { studid: "2023003", lname: "Cruz", fname: "Juan", score: 91 },
  { studid: "2023004", lname: "Reyes", fname: "Jose", score: 85 },
  { studid: "2023005", lname: "Dela Cruz", fname: "Ana", score: 93 }
])

use('exam')
db.quiz1.find()
