const express = require('express');
const { MongoClient, ObjectId } = require('mongodb');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const port = 3000;
const mongoUrl = 'mongodb://127.0.0.1:27017';
const dbName = 'ea6db';
let db;

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Connect to MongoDB
MongoClient.connect(mongoUrl).then(client => {
  db = client.db(dbName);
  console.log('✅ Connected to MongoDB');
}).catch(err => console.error('❌ DB Connection Error:', err));

// 🏠 Home page - Add employee form and list
app.get('/', async (req, res) => {
  const employees = await db.collection('employees').find().toArray();
  res.render('index', { employees });
});

// ➕ Add new employee
app.post('/add', async (req, res) => {
  const { empid, empname, position, department, salary } = req.body;
  await db.collection('employees').insertOne({ empid, empname, position, department, salary: parseFloat(salary) });
  res.redirect('/');
});

// 🔍 Search by empid
app.post('/search', async (req, res) => {
  const { empid } = req.body;
  const employee = await db.collection('employees').findOne({ empid });
  res.render('search', { employee });
});

// 🔄 Update employee
app.post('/update', async (req, res) => {
  const { empid, empname, position, department, salary } = req.body;
  await db.collection('employees').updateOne(
    { empid },
    { $set: { empname, position, department, salary: parseFloat(salary) } }
  );
  res.redirect('/');
});

// 🗑️ Delete employee
app.post('/delete', async (req, res) => {
  const { empid } = req.body;
  await db.collection('employees').deleteOne({ empid });
  res.redirect('/');
});

app.listen(port, () => {
  console.log(`🚀 App running at http://localhost:${port}`);
});
