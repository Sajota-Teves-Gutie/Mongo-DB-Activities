const express = require('express');
const { MongoClient, ObjectId } = require('mongodb');
const bodyParser = require('body-parser');
const path = require('path');
const session = require('express-session');

const app = express();
const port = 3000;
const mongoUrl = 'mongodb://127.0.0.1:27017';
const dbName = 'ea6db';
let db;

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(session({
  secret: 'yourSecretKey',
  resave: false,
  saveUninitialized: true
}));

// Connect to MongoDB
MongoClient.connect(mongoUrl).then(client => {
  db = client.db(dbName);
  console.log('✅ Connected to MongoDB');
}).catch(err => console.error('❌ DB Connection Error:', err));

// 🚪 Default route → redirect to register page
app.get('/', (req, res) => {
  res.redirect('/register');
});

// 📝 Render Register Form
app.get('/register', (req, res) => {
  res.render('register', { message: null });
});

// 🔐 Render Login Form
app.get('/login', (req, res) => {
  res.render('login', { message: null });
});

// ➕ Add new employee
app.post('/add', async (req, res) => {
  const { empid, empname, position, department, salary } = req.body;
  await db.collection('employees').insertOne({ empid, empname, position, department, salary: parseFloat(salary) });
  res.redirect('/home');
});

// 🔍 Search by empid
app.post('/search', async (req, res) => {
  const { empid } = req.body;
  const employee = await db.collection('employees').findOne({ empid });
  res.render('search', { employee });
});

// 🔄 Update employee
app.post('/update', async (req, res) => {
  const { empid, empname, position, department, salary } = req.body;
  await db.collection('employees').updateOne(
    { empid },
    { $set: { empname, position, department, salary: parseFloat(salary) } }
  );
  res.redirect('/home');
});

// 🗑️ Delete employee
app.post('/delete', async (req, res) => {
  const { empid } = req.body;
  await db.collection('employees').deleteOne({ empid });
  res.redirect('/home');
});

// 🧾 Registration Logic
app.post('/register', async (req, res) => {
  const { username, password } = req.body;
  const userExists = await db.collection('users').findOne({ username });
  if (userExists) {
    return res.render('register', { message: '⚠️ Username already taken.' });
  }
  await db.collection('users').insertOne({ username, password });
  res.render('register', { message: '✅ Registration successful!' });
});

// 🔑 Login Logic
app.post('/login', async (req, res) => {
  const { username, password } = req.body;
  const user = await db.collection('users').findOne({ username });
  if (!user || user.password !== password) {
    return res.render('login', { message: '❌ Invalid username or password.' });
  }
  req.session.user = username;
  res.redirect('/home');
});

// 🏠 Main Dashboard
app.get('/home', async (req, res) => {
  if (!req.session.user) return res.redirect('/login');
  const employees = await db.collection('employees').find().toArray();
  res.render('index', { employees, username: req.session.user });
});

// 🚪 Logout Route
app.get('/logout', (req, res) => {
  req.session.destroy(() => {
    res.redirect('/login');
  });
});

app.listen(port, () => {
  console.log(`🚀 App running at http://localhost:${port}`);
});
